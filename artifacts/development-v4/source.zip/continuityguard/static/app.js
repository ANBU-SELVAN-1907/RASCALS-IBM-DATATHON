"use strict";
const $ = (id) => document.getElementById(id);
let snapshot = null,
  selected = null,
  stream = null,
  explanationTimer = null,
  lastGeneration = null;
const pct = (v) => (v == null ? "—" : (100 * v).toFixed(1) + "%");
const node = (tag, text, cls) => {
  const e = document.createElement(tag);
  if (text != null) e.textContent = text;
  if (cls) e.className = cls;
  return e;
};
function toast(message) {
  $("toast").textContent = message;
  $("toast").hidden = false;
  setTimeout(() => ($("toast").hidden = true), 4500);
}
async function api(path, body) {
  const options = { headers: { "X-ContinuityGuard": "operator" } };
  if (body !== undefined) {
    options.method = "POST";
    options.headers["Content-Type"] = "application/json";
    options.body = JSON.stringify(body);
  }
  const r = await fetch("/api/" + path, options);
  const value = await r.json();
  if (!r.ok)
    throw Error(
      typeof value.detail === "string"
        ? value.detail
        : JSON.stringify(value.detail),
    );
  return value;
}
async function login(token) {
  await api("login", { token });
  $("login").hidden = true;
  $("console").hidden = false;
  connect();
  loadEvaluation();
}
$("loginForm").addEventListener("submit", async (event) => {
  event.preventDefault();
  try {
    await login($("token").value);
  } catch (error) {
    $("loginError").textContent = error.message;
  }
});
async function boot() {
  const params = new URLSearchParams(location.search);
  const token = params.get("token");
  if (token) {
    history.replaceState(null, "", location.pathname);
    try {
      await login(token);
      return;
    } catch (error) {
      $("loginError").textContent = error.message;
    }
  }
  try {
    const s = await api("state");
    $("login").hidden = true;
    $("console").hidden = false;
    render(s);
    connect();
    loadEvaluation();
  } catch (_) {}
}
function connect() {
  if (stream) stream.close();
  stream = new EventSource("/api/stream");
  stream.onmessage = (event) => {
    try {
      render(JSON.parse(event.data));
    } catch (error) {
      console.error(error);
    }
  };
  stream.onerror = () => {
    $("connectionDot").className = "";
    $("connectionText").textContent = "Reconnecting…";
  };
}
function render(s) {
  snapshot = s;
  if (lastGeneration !== s.generation) {
    lastGeneration = s.generation;
    if (s.mode === "synthetic") {
      $("scenario").value = s.scenario;
      $("speed").value = String(s.speed);
    }
  }
  $("sourceScope").textContent = s.source_label;
  $("sourceDetail").textContent =
    s.mode === "synthetic"
      ? "Inference runs on LinuxONE · no patient data"
      : "External input is isolated from the simulator";
  $("pause").disabled = Boolean(s.finished) || s.mode !== "synthetic";
  $("connectionDot").className = s.stale ? "" : "live";
  $("connectionText").textContent = s.stale
    ? "Telemetry stale"
    : "Stream connected";
  $("architecture").textContent =
    s.host.architecture + " · " + s.host.logical_cpus + " virtual CPUs";
  $("serviceCount").textContent = s.services.length + " / 4";
  $("incidentCount").textContent = s.incidents.length;
  $("incidentCaption").textContent = s.incidents.length
    ? "Evidence and runbooks available"
    : "Watching for persistent signals";
  $("latency").textContent = s.latency_p95_ms ?? "—";
  $("events").textContent = s.accepted.toLocaleString();
  $("queue").textContent =
    `Queue ${s.queue_batches} / ${s.queue_capacity} batches`;
  $("eventClock").textContent =
    s.mode === "synthetic" ? clock(s.second) + " / 05:00" : "External stream";
  $("windowCaption").textContent =
    s.mode === "synthetic"
      ? `Synthetic event time · ${s.speed}× ${s.speed === 1 ? "pace" : "replay"} · demo severity ${s.demo_strength}`
      : "External event time · 15 observations warm each service; forecasts are not validated for this distribution";
  $("streamAge").textContent =
    s.receipt_age_seconds == null
      ? "No telemetry yet"
      : `Last receipt ${s.receipt_age_seconds.toFixed(1)}s ago`;
  $("hostCpu").textContent = s.host.cpu_percent.toFixed(1) + "%";
  $("hostMemory").textContent = s.host.memory_percent.toFixed(1) + "%";
  $("modelStatus").textContent = s.processing_error
    ? "Processing error: " + s.processing_error
    : s.model_status;
  $("integrity").textContent = s.model.version + " · SHA-256 verified at load";
  $("rejects").textContent =
    `${s.rejected + s.rejected_batches} rejected · ${s.duplicates} duplicates`;
  $("pause").textContent = s.finished
    ? "Replay finished"
    : s.running
      ? "Pause"
      : "Resume";
  renderServices(s.services);
  renderIncidents(s.incidents);
  drawChart(s.chart);
}
function clock(t) {
  return (
    Math.floor(t / 60)
      .toString()
      .padStart(2, "0") +
    ":" +
    (t % 60).toString().padStart(2, "0")
  );
}
function renderServices(services) {
  const parent = $("serviceRows");
  parent.replaceChildren();
  for (const s of services) {
    const row = node("div", null, "service-row");
    const name = node("div", null, "service-name");
    name.append(
      node("strong", s.service),
      node(
        "small",
        s.service === "database" ? "Shared dependency" : "↳ database",
      ),
    );
    row.append(name, node("span", s.latency_p95_ms.toFixed(0) + " ms"));
    const risk = node("div", pct(s.forecast_risk));
    const track = node("div", null, "risk-track");
    const fill = node("i");
    fill.style.width = 100 * (s.forecast_risk || 0) + "%";
    track.append(fill);
    risk.append(track);
    row.append(risk);
    row.append(
      node(
        "span",
        !s.warm
          ? "Warming up"
          : s.breached
            ? "SLO breached"
            : s.flagged
              ? "Watch"
              : "Stable",
        "pill " + (s.breached ? "danger" : s.flagged ? "warning" : "calm"),
      ),
    );
    parent.append(row);
  }
}
function renderIncidents(incidents) {
  if (!incidents.length) {
    selected = null;
    $("emptyIncident").hidden = false;
    $("incidentBody").hidden = true;
    $("incidentTitle").textContent = "No incident selected";
    $("incidentTag").textContent = "Watching";
    $("incidentTag").className = "pill calm";
    return;
  }
  const exists = incidents.some((i) => i.id === selected);
  if (!exists) selected = incidents[0].id;
  const select = $("incidentSelect");
  const key = incidents.map((i) => i.id).join();
  if (select.dataset.key !== key) {
    select.replaceChildren();
    for (const i of incidents)
      select.append(new Option(i.service + " · " + i.id.slice(0, 6), i.id));
    select.dataset.key = key;
  }
  select.value = selected;
  const incident = incidents.find((i) => i.id === selected);
  if ($("incidentBody").dataset.id === incident.id) return;
  $("incidentBody").dataset.id = incident.id;
  $("emptyIncident").hidden = true;
  $("incidentBody").hidden = false;
  $("incidentTitle").textContent = incident.already_breached
    ? "Service disruption detected"
    : "Developing service risk";
  $("incidentTag").textContent = incident.already_breached
    ? "Detected"
    : "Early signal";
  $("incidentTag").className =
    "pill " + (incident.already_breached ? "danger" : "warning");
  $("incidentDescription").textContent =
    `${incident.service} · forecast score ${pct(incident.risk)} · novelty percentile ${pct(incident.novelty_percentile)}. Suspected source: ${incident.suspected_source}.`;
  $("affected").replaceChildren(
    ...incident.affected_services.map((s) => node("span", s)),
  );
  $("evidence").replaceChildren(
    ...incident.evidence.map((e) => {
      const row = node("div");
      const label = node("span");
      label.append(node("small", e.id), document.createTextNode(e.label));
      row.append(label, node("b", e.value + " " + e.unit));
      return row;
    }),
  );
  $("runbookTitle").textContent =
    incident.runbook.id + " · " + incident.runbook.title;
  $("runbookSteps").replaceChildren(
    ...incident.runbook.steps.map((s) => node("li", s)),
  );
  $("explanation").hidden = true;
  $("response").hidden = true;
  $("preview").disabled = incident.runbook.action === "none";
  $("preview").textContent =
    incident.runbook.action === "none"
      ? "Operator investigation required"
      : "Preview a sandbox response ↗";
  if (explanationTimer) clearInterval(explanationTimer);
}
$("incidentSelect").addEventListener("change", () => {
  selected = $("incidentSelect").value;
  $("incidentBody").dataset.id = "";
  renderIncidents(snapshot.incidents);
});
$("start").addEventListener("click", async () => {
  try {
    await api("scenario", {
      name: $("scenario").value,
      speed: Number($("speed").value),
      seed: 101,
    });
    $("incidentBody").dataset.id = "";
    toast(
      "New controlled scenario started. Alerts need 15 observations to warm up.",
    );
  } catch (e) {
    toast(e.message);
  }
});
$("pause").addEventListener("click", async () => {
  try {
    await api("pause", {});
  } catch (e) {
    toast(e.message);
  }
});
$("preview").addEventListener("click", async () => {
  if (!selected) return;
  const incidentId = selected,
    generation = snapshot.generation;
  const button = $("preview");
  button.disabled = true;
  try {
    const r = await api("response-preview", { incident_id: incidentId });
    if (selected !== incidentId || snapshot.generation !== generation) return;
    const box = $("response");
    box.replaceChildren();
    box.hidden = false;
    if (r.urgent_success_difference != null) {
      box.append(
        node(
          "strong",
          `${r.urgent_success_difference >= 0 ? "+" : ""}${r.urgent_success_difference} successful urgent-results transactions`,
        ),
        node(
          "p",
          `Service-breach duration: ${r.urgent_breach_seconds_without}s without action → ${r.urgent_breach_seconds_with}s with action.`,
        ),
        node(
          "p",
          `Tradeoff: ${r.deferred_batch_requests} optional batch requests deferred.`,
        ),
        node(
          "small",
          r.scope +
            ". This previews a response; no host or real service is modified.",
        ),
      );
    } else box.append(node("p", r.scope));
  } catch (e) {
    toast(e.message);
  } finally {
    button.disabled = false;
  }
});
$("explain").addEventListener("click", async () => {
  if (!selected) return;
  const incidentId = selected;
  try {
    const r = await api("explain", { incident_id: incidentId });
    if (r.status === "busy") {
      toast(r.message);
      return;
    }
    $("explanation").hidden = false;
    $("explanation").textContent =
      "Local Granite is generating a constrained, evidence-grounded explanation…";
    const poll = async () => {
      const value = await api("explanation/" + incidentId);
      if (value.status === "complete") {
        clearInterval(explanationTimer);
        if (selected !== incidentId) return;
        $("explanation").replaceChildren(
          node("p", value.summary),
          node(
            "small",
            `${value.mode} · ${value.elapsed_seconds}s · ${value.evidence_ids.join(", ")} · ${value.runbook_id}`,
          ),
        );
      }
    };
    if (explanationTimer) clearInterval(explanationTimer);
    explanationTimer = setInterval(
      () => poll().catch((e) => toast(e.message)),
      1800,
    );
    await poll();
  } catch (e) {
    toast(e.message);
  }
});
function drawChart(points) {
  const canvas = $("chart"),
    rect = canvas.getBoundingClientRect(),
    dpr = devicePixelRatio || 1;
  if (rect.width === 0) return;
  canvas.width = Math.round(rect.width * dpr);
  canvas.height = Math.round(rect.height * dpr);
  const ctx = canvas.getContext("2d");
  ctx.scale(dpr, dpr);
  const w = rect.width,
    h = rect.height,
    left = 40,
    right = 9,
    top = 14,
    bottom = 25;
  const max = Math.max(1250, ...points.map((p) => p.latency)) * 1.08;
  ctx.font = "9px Segoe UI";
  ctx.lineWidth = 1;
  for (let i = 0; i < 4; i++) {
    const value = Math.round((max * i) / 3),
      y = h - bottom - ((h - top - bottom) * i) / 3;
    ctx.strokeStyle = "#eaf0e8";
    ctx.beginPath();
    ctx.moveTo(left, y);
    ctx.lineTo(w - right, y);
    ctx.stroke();
    ctx.fillStyle = "#94a395";
    ctx.fillText(value + "", 2, y + 3);
  }
  const py = (v) => h - bottom - (v / max) * (h - top - bottom);
  ctx.setLineDash([4, 4]);
  ctx.strokeStyle = "#c68772";
  ctx.beginPath();
  ctx.moveTo(left, py(1000));
  ctx.lineTo(w - right, py(1000));
  ctx.stroke();
  ctx.setLineDash([]);
  if (points.length > 1) {
    const px = (i) =>
      left + (i / Math.max(points.length - 1, 45)) * (w - left - right);
    ctx.beginPath();
    ctx.moveTo(px(0), h - bottom);
    points.forEach((p, i) => ctx.lineTo(px(i), py(p.latency)));
    ctx.lineTo(px(points.length - 1), h - bottom);
    ctx.closePath();
    const gradient = ctx.createLinearGradient(0, top, 0, h);
    gradient.addColorStop(0, "#228a6b20");
    gradient.addColorStop(1, "#228a6b02");
    ctx.fillStyle = gradient;
    ctx.fill();
    ctx.beginPath();
    points.forEach((p, i) =>
      i ? ctx.lineTo(px(i), py(p.latency)) : ctx.moveTo(px(i), py(p.latency)),
    );
    ctx.strokeStyle = "#24896c";
    ctx.lineWidth = 2;
    ctx.stroke();
    const last = points.length - 1;
    ctx.fillStyle = "#24896c";
    ctx.beginPath();
    ctx.arc(px(last), py(points[last].latency), 3, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = "#8b9c8e";
    ctx.fillText("Latest " + points.length + " observations", left, h - 5);
  } else {
    ctx.fillStyle = "#9baa9d";
    ctx.fillText("Waiting for telemetry", left + 20, h / 2);
  }
}
document.querySelectorAll(".nav").forEach((button) =>
  button.addEventListener("click", () => {
    document
      .querySelectorAll(".nav")
      .forEach((b) => b.classList.toggle("active", b === button));
    $("liveView").hidden = button.dataset.view !== "live";
    $("evaluationView").hidden = button.dataset.view !== "evaluation";
    if (button.dataset.view === "live" && snapshot) drawChart(snapshot.chart);
  }),
);
async function loadEvaluation() {
  try {
    const r = await api("report");
    $("evaluationScope").textContent =
      `${r.split.test_runs} final test runs · ${r.systems.ContinuityGuard.incidents} service incidents · ${r.systems.ContinuityGuard.healthy_service_hours.toFixed(1)} healthy service-hours · ${r.selected_model}`;
    const tbody = $("results").querySelector("tbody");
    tbody.replaceChildren();
    for (const [name, m] of Object.entries(r.systems)) {
      const row = node("tr");
      [
        name,
        pct(m.early_warning_recall),
        pct(m.incident_precision),
        m.median_early_lead_seconds == null
          ? "—"
          : m.median_early_lead_seconds + "s",
        m.false_alarms_per_healthy_service_hour?.toFixed(2) ?? "—",
        m.missed,
      ].forEach((text) => row.append(node("td", text)));
      tbody.append(row);
    }
    $("splitSummary").replaceChildren(
      ...[
        ["Training", r.split.training_runs],
        ["Calibration", r.split.calibration_runs],
        ["Validation", r.split.validation_runs],
        ["Final test", r.split.test_runs],
      ].map(([label, value]) => {
        const box = node("div");
        box.append(node("strong", value), node("small", label));
        return box;
      }),
    );
    $("limitations").replaceChildren(
      ...r.limitations.map((text) => node("li", text)),
    );
  } catch (e) {
    toast(e.message);
  }
}
$("external").addEventListener("click", async () => {
  try {
    await api("external-session", {});
    toast("External session ready. Send validated windows to /api/events.");
  } catch (e) {
    toast(e.message);
  }
});
$("platformProof").addEventListener("click", async () => {
  try {
    $("platformResult").textContent = JSON.stringify(
      await api("platform-proof"),
      null,
      2,
    );
  } catch (e) {
    toast(e.message);
  }
});
$("audit").addEventListener("click", async () => {
  try {
    $("auditResult").textContent = JSON.stringify(await api("audit"), null, 2);
  } catch (e) {
    toast(e.message);
  }
});
window.addEventListener("resize", () => snapshot && drawChart(snapshot.chart));
boot();
